document.addEventListener('DOMContentLoaded', () => {
    console.log('Hospital Management System Loaded');
});
