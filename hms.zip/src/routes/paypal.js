const express = require('express');
const paypal = require('paypal-rest-sdk');
const db = require('../config');
const nodemailer = require('nodemailer');
const router = express.Router(); // Create a router

// PayPal configuration
paypal.configure({
    'mode': 'sandbox', // or 'live' for production
    'client_id': 'AQ7IX0U-EQu1aJGryRHFG-3rRwZiUvnz-soUhjp3qrumHsxIhbCPAoF2jdx5zDVNwMP1ObnV4FZqJU79',
    'client_secret': 'ECmx1jWw8XW4qctniAiy8psBZ45F53SUxsknP5F612sAz69440atKb2stizZA73zSGfyzUHatyU6SR1o'
});

// Route: Pay Consultation Fee
router.post('/payConsultation', (req, res) => {
    const { fee, appdate, apptime, DoctorId, patientId } = req.body;

    // Validate input data
    if (!fee || !appdate || !apptime || !DoctorId || !patientId) {
        return res.status(400).json({ success: false, message: 'Missing required fields for payment' });
    }

    const create_payment_json = {
        "intent": "sale",
        "payer": { "payment_method": "paypal" },
        "redirect_urls": {
            "return_url": `http://localhost:3000/paypal/successConsultation?fee=${fee}&appdate=${appdate}&apptime=${apptime}&DoctorId=${DoctorId}&patientId=${patientId}`,
            "cancel_url": "http://localhost:3000/paypal/cancel"
        },
        "transactions": [{
            "item_list": {
                "items": [{
                    "name": "Consultation Fee",
                    "sku": "001",
                    "price": fee,
                    "currency": "USD",
                    "quantity": 1
                }]
            },
            "amount": {
                "currency": "USD",
                "total": fee
            },
            "description": "Payment for consultation fee."
        }]
    };

    paypal.payment.create(create_payment_json, function (error, payment) {
        if (error) {
            console.error('PayPal error:', error);
            res.status(500).json({ success: false, message: 'Payment creation failed' });
        } else {
            const approvalUrl = payment.links.find(link => link.rel === 'approval_url');
            if (approvalUrl) {
                res.json({ success: true, url: approvalUrl.href });
            }
        }
    });
});

// Route: Success for Consultation Payment
router.get('/successConsultation', (req, res) => {
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const { fee, appdate, apptime, DoctorId, patientId } = req.query;

    const execute_payment_json = {
        "payer_id": payerId,
        "transactions": [{
            "amount": {
                "currency": "USD",
                "total": fee
            }
        }]
    };

    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment) {
        if (error) {
            console.error('Payment execution error:', error);
            res.send('<script>alert("Payment failed!"); window.location.href = "/";</script>');
        } else {
            const bookAppointmentQuery = 
                `INSERT INTO Appointment (PatientID, DoctorID, AppointmentDate, AppointmentStartTime)
                VALUES (?, ?, ?, ?)`;

            db.query(bookAppointmentQuery, [patientId, DoctorId, appdate, apptime], (err, result) => {
                if (err) {
                    console.error('Database error during appointment booking:', err);
                    res.send('<script>alert("Payment was successful, but booking the appointment failed. Please contact our support team for assistance."); window.location.href = "/";</script>');
                } else {
                    // Send an email to the patient after successful appointment booking
                    sendAppointmentConfirmationEmail(patientId, DoctorId, appdate, apptime)
                        .then(() => {
                            res.send('<script>alert("Your appointment has been successfully booked!"); window.location.href = "/";</script>');
                        })
                        .catch(emailError => {
                            console.error('Error sending email:', emailError);
                            res.send('<script>alert("Appointment booked, but failed to send confirmation email. Please check your appointment details."); window.location.href = "/";</script>');
                        });
                }
            });
        }
    });
});

// Function to send appointment confirmation email
function sendAppointmentConfirmationEmail(patientId, DoctorId, appdate, apptime) {
    return new Promise((resolve, reject) => {
        // Query to fetch patient details
        const patientQuery = `SELECT Email FROM Patient WHERE PatientID = ?`;
        const doctorQuery = `SELECT DoctorName FROM Doctor WHERE DoctorID = ?`;

        db.query(patientQuery, [patientId], (err, patientResult) => {
            if (err) {
                console.error('Database error when fetching patient details:', err);
                return reject('Failed to fetch patient details due to a database error');
            }

            if (patientResult.length === 0) {
                console.error('No patient found with the provided PatientID:', patientId);
                return reject('Failed to fetch patient details: No patient found');
            }

            const patientEmail = patientResult[0].Email;

            // Query to fetch doctor details
            db.query(doctorQuery, [DoctorId], (err, doctorResult) => {
                if (err) {
                    console.error('Database error when fetching doctor details:', err);
                    return reject('Failed to fetch doctor details due to a database error');
                }

                if (doctorResult.length === 0) {
                    console.error('No doctor found with the provided DoctorID:', DoctorId);
                    return reject('Failed to fetch doctor details: No doctor found');
                }

                const doctorName = doctorResult[0].DoctorName;

                // Create the email transporter
                const transporter = nodemailer.createTransport({
                    service: 'gmail',
                    host: 'smtp.gmail.com',
                    port: 465,
                    secure: true, // SSL
                    auth: {
                        user: 'saianurag234@gmail.com',
                        pass: 'mxfh ujdv sjnn rman'
                    }
                });

                const mailOptions = {
                    from: '"Amrita Hospitals" <no-reply@kkvshospitals.com>', // Display name with email
                    to: patientEmail,
                    subject: 'Appointment Confirmation - KKVS Hospitals',
                    html: `
                        <div style="font-family: 'Arial', sans-serif; color: #333; background-color: #f9f9f9; padding: 20px;">
                            <div style="background-color: #0066cc; padding: 20px; text-align: center;">
                                <h1 style="color: #fff; font-size: 24px; margin: 0;">Appointment Confirmation</h1>
                            </div>
                            <div style="background-color: #fff; padding: 20px; border-radius: 10px;">
                                <p style="font-size: 16px;">Dear Patient,</p>
                                <p style="font-size: 16px;">We are pleased to confirm your appointment with <strong>Dr.${doctorName}</strong> on <strong>${appdate}</strong> at <strong>${apptime}</strong>.</p>
                                <h3 style="color: #0066cc; font-size: 18px;">Appointment Details:</h3>
                                <ul style="list-style: none; padding-left: 0; font-size: 16px;">
                                    <li><strong>Doctor:</strong> ${doctorName}</li>
                                    <li><strong>Date:</strong> ${appdate}</li>
                                    <li><strong>Time:</strong> ${apptime}</li>
                                    <li><strong>Location:</strong> KKVS Hospitals, Rajahmahendravaram</li>
                                </ul>
                                <p style="font-size: 16px;">Please arrive at least 15 minutes before your appointment. If you need to reschedule, contact us at (+91) 9038558532 or reply to this email.</p>
                                <p style="font-size: 16px;">Thank you for choosing KKVS Hospitals. We look forward to serving you!</p>
                                <p style="font-size: 16px;">Best Regards,</p>
                                <p style="font-size: 16px;"><strong>KKVS Hospitals Team</strong></p>
                            </div>
                            <div style="background-color: #0066cc; padding: 20px; text-align: center; font-size: 12px; color: #fff;">
                                <p>This is an automated email. Please do not reply.</p>
                                <p>&copy; 2024 KKVS Hospitals. All rights reserved.</p>
                            </div>
                        </div>
                    `
                };

                // Send the email
                transporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                        console.error('Error sending email:', error);
                        return reject(error);
                    }
                    resolve(info);
                });
            });
        });
    });
}


// Route: Pay Room Rent
router.post('/payRoomRent', (req, res) => {
    const { billId, amount } = req.body;

    if (!billId || !amount) {
        return res.status(400).json({ success: false, message: 'Missing required fields for payment' });
    }

    const create_payment_json = {
        "intent": "sale",
        "payer": { "payment_method": "paypal" },
        "redirect_urls": {
            "return_url": `http://localhost:3000/paypal/successRoomRent?billId=${billId}&amount=${amount}`,
            "cancel_url": "http://localhost:3000/paypal/cancel"
        },
        "transactions": [{
            "item_list": {
                "items": [{
                    "name": "Room Rent",
                    "sku": "002",
                    "price": amount,
                    "currency": "USD",
                    "quantity": 1
                }]
            },
            "amount": {
                "currency": "USD",
                "total": amount
            },
            "description": "Payment for room rent."
        }]
    };

    paypal.payment.create(create_payment_json, function (error, payment) {
        if (error) {
            console.error('PayPal error:', error);
            res.status(500).json({ success: false, message: 'Payment creation failed' });
        } else {
            const approvalUrl = payment.links.find(link => link.rel === 'approval_url');
            if (approvalUrl) {
                res.json({ success: true, url: approvalUrl.href });
            }
        }
    });
});

// Route: Success for Room Rent Payment
router.get('/successRoomRent', (req, res) => {
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const { billId, amount } = req.query;

    const execute_payment_json = {
        "payer_id": payerId,
        "transactions": [{
            "amount": {
                "currency": "USD",
                "total": amount
            }
        }]
    };

    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment) {
        if (error) {
            console.error('Payment execution error:', error);
            res.send('<script>alert("Payment failed!"); window.location.href = "/";</script>');
        } else {
            const updateBillStatusQuery = `
                UPDATE RoomRent
                SET BillStatus = 'Paid'
                WHERE BillID = ?
            `;

            db.query(updateBillStatusQuery, [billId], (err, result) => {
                if (err) {
                    console.error('Database error during bill status update:', err);
                    res.send('<script>alert("Payment was successful, but updating the bill status failed. Please contact our support team for assistance."); window.location.href = "/";</script>');
                } else {
                    res.send('<script>alert("Payment successful and bill status updated!"); window.location.href = "/";</script>');
                }
            });
        }
    });
});


router.post('/payLabBill', (req, res) => {
    const { billId, amount } = req.body;

    if (!billId || !amount) {
        return res.status(400).json({ success: false, message: 'Missing required fields for payment' });
    }

    const create_payment_json = {
        "intent": "sale",
        "payer": { "payment_method": "paypal" },
        "redirect_urls": {
            "return_url": `http://localhost:3000/paypal/successLabBill?billId=${billId}&amount=${amount}`,
            "cancel_url": "http://localhost:3000/paypal/cancel"
        },
        "transactions": [{
            "item_list": {
                "items": [{
                    "name": "Lab Bill",
                    "sku": "003",
                    "price": amount,
                    "currency": "USD",
                    "quantity": 1
                }]
            },
            "amount": {
                "currency": "USD",
                "total": amount
            },
            "description": "Payment for lab bill."
        }]
    };

    paypal.payment.create(create_payment_json, function (error, payment) {
        if (error) {
            console.error('PayPal error:', error);
            res.status(500).json({ success: false, message: 'Payment creation failed' });
        } else {
            const approvalUrl = payment.links.find(link => link.rel === 'approval_url');
            if (approvalUrl) {
                res.json({ success: true, url: approvalUrl.href });
            }
        }
    });
});


router.get('/successLabBill', (req, res) => {
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const { billId, amount } = req.query;

    const execute_payment_json = {
        "payer_id": payerId,
        "transactions": [{
            "amount": {
                "currency": "USD",
                "total": amount
            }
        }]
    };

    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment) {
        if (error) {
            console.error('Payment execution error:', error);
            res.send('<script>alert("Payment failed!"); window.location.href = "/";</script>');
        } else {
            const updateBillStatusQuery = `
                UPDATE LabBill
                SET BillStatus = 'Paid'
                WHERE BillID = ?
            `;

            db.query(updateBillStatusQuery, [billId], (err, result) => {
                if (err) {
                    console.error('Database error during bill status update:', err);
                    res.send('<script>alert("Payment was successful, but updating the bill status failed. Please contact our support team for assistance."); window.location.href = "/";</script>');
                } else {
                    res.send('<script>alert("Payment successful and bill status updated!"); window.location.href = "/";</script>');
                }
            });
        }
    });
});

router.get('/cancel', (req, res) => {
    res.send('<script>alert("Payment canceled by user."); window.location.href = "/";</script>');
});

module.exports = router; // Export the router
