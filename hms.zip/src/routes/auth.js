const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../config'); // Assuming you have a MySQL connection setup here
const router = express.Router();
const moment = require('moment');
const nodemailer = require('nodemailer');

// Patient Login Route
router.post('/patientlogin', (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ success: false, message: 'Email and password are required' });
    }

    db.query('SELECT userpassword FROM PatientLogin WHERE email = ?', [email], (err, results) => {
        if (err) {
            console.error("Database error: ", err);
            return res.status(500).json({ success: false, message: 'Server error' });
        }

        if (results.length === 0) {
            return res.status(400).json({ success: false, message: 'Email not registered' });
        }

        const dbPassword = results[0].userpassword;

        bcrypt.compare(password, dbPassword, (err, isMatch) => {
            if (err) {
                console.error("Bcrypt error: ", err);
                return res.status(500).json({ success: false, message: 'Server error' });
            }

            if (!isMatch) {
                return res.status(400).json({ success: false, message: 'Password incorrect' });
            }

            db.query('SELECT PatientID, FirstName, LastName FROM Patient WHERE Email = ?', [email], (err, patientResults) => {
                if (err) {
                    console.error("Database error: ", err);
                    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' });
                }

                if (patientResults.length === 0) {
                    return res.status(400).json({ success: false, message: 'Patient details not found' });
                }

                const { PatientID, FirstName, LastName } = patientResults[0];
                const name = `${FirstName} ${LastName}`;

                res.status(200).json({ success: true, message: 'Login successful', name, pid:PatientID});
            });
        });
    });
});

// Patient Registration Route
router.post('/patientregister', (req, res) => {
    const {
        first_name, last_name, gender, mobile, email, dob, marital_status,
        address, city, zipcode, state, country, ec_email, ec_mobile, ec_relationship,
        weight, blood_group, tobacco_usage, alcohol_intake, is_diabetic, is_having_bp,
        password, cpassword
    } = req.body;

    if (password !== cpassword) {
        return res.status(400).json({ success: false, message: 'Passwords do not match' });
    }

    db.query('SELECT * FROM Patient WHERE Email = ?', [email], (err, results) => {
        if (err) {
            console.error("Database error during patient existence check:", err);
            return res.status(500).json({ success: false, message: 'Server error' });
        }

        if (results.length > 0) {
            return res.status(400).json({ success: false, message: 'Patient Already Registered' });
        }

        const saltRounds = 10;

        bcrypt.hash(password, saltRounds, (err, hashedPassword) => {
            if (err) {
                console.error('Password hash error:', err);
                return res.status(500).json({ success: false, message: 'Failed to process password. Please try again.' });
            }

            db.beginTransaction((err) => {
                if (err) {
                    console.error('Transaction error:', err);
                    return res.status(500).json({ success: false, message: 'Transaction error. Please try again.' });
                }

                const insertPatientQuery = `
                    INSERT INTO Patient (FirstName, LastName, Gender, Mobile, Email, DOB, MaritalStatus)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                `;
                const insertAddressQuery = `
                    INSERT INTO PatientAddress (PatientID, Address, City, ZipCode, State, Country)
                    VALUES (?, ?, ?, ?, ?, ?)
                `;
                const insertEmergencyContactQuery = `
                    INSERT INTO EmergencyContact (PatientID, Email, MobileNumber, RelationshipToPatient)
                    VALUES (?, ?, ?, ?)
                `;
                const insertMedicalBackgroundQuery = `
                    INSERT INTO PatientMedicalBackground (PatientID, Weight, BloodGroup, TobaccoUsage, AlcoholIntake, IsDiabetic, IsHavingBP)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                `;
                const insertPatientLoginQuery = `
                    INSERT INTO PatientLogin (email, userpassword)
                    VALUES (?, ?)
                `;

                db.query(insertPatientQuery, [first_name, last_name, gender, mobile, email, dob, marital_status], (err, result) => {
                    if (err) {
                        console.error('Patient insert error:', err);
                        return db.rollback(() => {
                            res.status(500).json({ success: false, message: 'Failed to insert patient information.' });
                        });
                    }

                    const patientId = result.insertId;

                    db.query(insertAddressQuery, [patientId, address, city, zipcode, state, country], (err) => {
                        if (err) {
                            console.error('Address insert error:', err);
                            return db.rollback(() => {
                                res.status(500).json({ success: false, message: 'Failed to insert address information.' });
                            });
                        }

                        db.query(insertEmergencyContactQuery, [patientId, ec_email, ec_mobile, ec_relationship], (err) => {
                            if (err) {
                                console.error('Emergency contact insert error:', err);
                                return db.rollback(() => {
                                    res.status(500).json({ success: false, message: 'Failed to insert emergency contact information.' });
                                });
                            }

                            db.query(insertMedicalBackgroundQuery, [patientId, weight, blood_group, tobacco_usage, alcohol_intake, is_diabetic, is_having_bp], (err) => {
                                if (err) {
                                    console.error('Medical background insert error:', err);
                                    return db.rollback(() => {
                                        res.status(500).json({ success: false, message: 'Failed to insert medical background information.' });
                                    });
                                }

                                db.query(insertPatientLoginQuery, [email, hashedPassword], (err) => {
                                    if (err) {
                                        console.error('Patient login insert error:', err);
                                        return db.rollback(() => {
                                            res.status(500).json({ success: false, message: 'Failed to insert login information.' });
                                        });
                                    }

                                    db.commit((err) => {
                                        if (err) {
                                            console.error('Commit error:', err);
                                            return db.rollback(() => {
                                                res.status(500).json({ success: false, message: 'Commit error. Please try again.' });
                                            });
                                        }

                                        res.status(200).json({ success: true, message: 'Registration successful', patientId });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });
});

router.get('/getdoctorid', (req, res) => {
    console.log('Request received at /getdoctorid'); // Adjusted log to match the actual route

    const doctorName = req.query.name;

    console.log(doctorName)

    if (!doctorName) {
        console.error('No doctor name provided in request');
        return res.status(400).json({ success: false, message: 'Doctor name is required' });
    }

    const query = 'SELECT DoctorID FROM Doctor WHERE DoctorName = ?';

    db.query(query, [doctorName], (err, results) => {
        if (err) {
            console.error("Database error during doctor ID retrieval:", err);
            return res.status(500).json({ success: false, message: 'Server error' });
        }

        if (results.length === 0) {
            console.warn(`Doctor not found: ${doctorName}`);
            return res.status(404).json({ success: false, message: 'Doctor not found' });
        }

        const doctorId = results[0].DoctorID;
        console.log(`Doctor ID found for ${doctorName}: ${doctorId}`);
        res.status(200).json({ success: true, doctorId });
    });
});


// Assuming you have an Express app setup
router.get('/getdoctors', (req, res) => {
    const query = `
        SELECT DoctorID, DoctorName
        FROM Doctor
        WHERE IsActive = TRUE
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ success: false, message: 'Database query error' });
        }
        res.json({ success: true, doctors: results });
    });
});


// Get Available Slots Route
router.get('/getavailableslots', (req, res) => {
    console.log('Request received at /getavailableslots');
    console.log('Query Parameters:', req.query);

    const { doctor_id, date } = req.query;

    if (!doctor_id || !date) {
        console.log('Missing doctor_id or date');
        return res.status(400).json({ success: false, message: 'Doctor ID and date are required' });
    }

    // Get the current date and time
    const currentDate = new Date().toISOString().split('T')[0];
    const currentTime = new Date().toTimeString().split(' ')[0]; // Format as HH:MM:SS

    // Construct the query with an additional condition for the current date
    let query = `
        SELECT 
            ADDTIME('10:00:00', SEC_TO_TIME(slot * 1800)) AS AvailableSlot
        FROM (
            SELECT 0 AS slot UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 
            UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9 
            UNION ALL SELECT 10 UNION ALL SELECT 11 UNION ALL SELECT 12 UNION ALL SELECT 13 
        ) AS slots
        WHERE 
            (ADDTIME('10:00:00', SEC_TO_TIME(slot * 1800)) < '12:30:00' OR 
            ADDTIME('10:00:00', SEC_TO_TIME(slot * 1800)) > '13:59:00')
            AND ADDTIME('10:00:00', SEC_TO_TIME(slot * 1800)) < '16:30:00'
            AND NOT EXISTS (
                SELECT 1 
                FROM Appointment 
                WHERE DoctorID = ? 
                AND AppointmentDate = ? 
                AND AppointmentStartTime = ADDTIME('10:00:00', SEC_TO_TIME(slot * 1800))
                AND AppointmentStatus IN ('Scheduled', 'Rescheduled')
            )
    `;

    // Append additional time condition if the requested date is today
    if (date === currentDate) {
        query += ` AND ADDTIME('10:00:00', SEC_TO_TIME(slot * 1800)) > ?`;
    }

    query += ';';

    // Execute the query with the appropriate parameters
    const queryParams = date === currentDate ? [doctor_id, date, currentTime] : [doctor_id, date];

    db.query(query, queryParams, (err, results) => {
        if (err) {
            console.error("Database error during slot retrieval:", err);
            return res.status(500).json({ success: false, message: 'Server error' });
        }

        console.log('Query Results:', results);

        const availableSlots = results.map(slot => slot.AvailableSlot);

        if (availableSlots.length === 0) {
            console.log('No slots available for the given doctor and date.');
        } else {
            console.log('Available slots:', availableSlots);
        }

        res.status(200).json({ success: true, availableSlots });
    });
});


// Book an Appointment Route
router.post('/bookappointment', (req, res) => {
    console.log(req.body);
    const { appdate, apptime, DoctorId, patientId } = req.body;

    if (!patientId || !DoctorId || !appdate || !apptime) {
        console.log('Missing required fields');
        return res.status(400).json({ success: false, message: 'All fields are required' });
    }

    const bookAppointmentQuery = `
        INSERT INTO Appointment (PatientID, DoctorID, AppointmentDate, AppointmentStartTime)
        VALUES (?, ?, ?, ?)
    `;

    db.query(bookAppointmentQuery, [patientId, DoctorId, appdate, apptime], (err, result) => {
        if (err) {
            console.error('Database error during appointment booking:', err);
            return res.status(500).json({ success: false, message: 'Failed to book appointment. Please try again.' });
        }

        res.status(200).json({ success: true, message: 'Appointment booked successfully', appointmentId: result.insertId });
    });
});

router.get('/getAppointmentHistory', (req, res) => {
    const { patientId } = req.query;

    if (!patientId) {
        return res.status(400).json({ success: false, message: 'Patient ID is required' });
    }

    const query = `
        SELECT a.AppointmentID, d.DoctorName, 
               DATE_FORMAT(a.AppointmentDate, '%Y-%m-%d') AS AppointmentDate, 
               TIME_FORMAT(a.AppointmentStartTime, '%H:%i') AS AppointmentStartTime, 
               a.AppointmentStatus
        FROM Appointment a
        JOIN Doctor d ON a.DoctorID = d.DoctorID
        WHERE a.PatientID = ?
        ORDER BY a.AppointmentDate DESC, a.AppointmentStartTime DESC
    `;

    db.query(query, [patientId], (err, results) => {
        if (err) {
            console.error('Database error while retrieving appointment history:', err);
            return res.status(500).json({ success: false, message: 'Failed to retrieve appointment history. Please try again.' });
        }

        // Adjust for any timezone differences if needed
        results = results.map(appointment => {
            appointment.AppointmentDate = new Date(appointment.AppointmentDate).toISOString().split('T')[0];
            return appointment;
        });

        res.status(200).json({ success: true, appointments: results });
    });
});


router.post('/cancelAppointment', (req, res) => {
    const { appointmentId } = req.body;

    if (!appointmentId) {
        return res.status(400).json({ success: false, message: 'Appointment ID is required' });
    }

    const cancelQuery = `
        UPDATE Appointment
        SET AppointmentStatus = 'Cancelled'
        WHERE AppointmentID = ? AND (AppointmentDate > CURDATE() OR (AppointmentDate = CURDATE() AND AppointmentStartTime > CURTIME()))
    `;

    db.query(cancelQuery, [appointmentId], (err, result) => {
        if (err) {
            console.error('Database error while cancelling appointment:', err);
            return res.status(500).json({ success: false, message: 'Failed to cancel appointment. Please try again.' });
        }

        if (result.affectedRows === 0) {
            return res.status(400).json({ success: false, message: 'Cannot cancel past appointments or invalid appointment ID.' });
        }

        res.status(200).json({ success: true, message: 'Appointment cancelled successfully' });
    });
});


router.post('/doctorlogin', (req, res) => {
    console.log(req.body);
    const { doctor_id, password } = req.body;

    if (!doctor_id || !password) {
        return res.status(400).json({ success: false, message: 'Doctor ID and password are required' });
    }

    db.query('SELECT docpassword FROM DoctorLogin WHERE doctor_id = ?', [doctor_id], (err, results) => {
        if (err) {
            console.error("Database error: ", err);
            return res.status(500).json({ success: false, message: 'Server error' });
        }

        if (results.length === 0) {
            return res.status(400).json({ success: false, message: 'Doctor ID not registered' });
        }

        const dbPassword = results[0].docpassword; // Ensure consistency here

        bcrypt.compare(password, dbPassword, (err, isMatch) => {
            if (err) {
                console.error("Bcrypt error: ", err);
                return res.status(500).json({ success: false, message: 'Server error' });
            }

            if (!isMatch) {
                return res.status(400).json({ success: false, message: 'Password incorrect' });
            }

            db.query('SELECT DoctorName FROM Doctor WHERE DoctorID = ?', [doctor_id], (err, doctorResults) => {
                if (err) {
                    console.error("Database error: ", err);
                    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' });
                }
            
                if (doctorResults.length === 0) {
                    return res.status(400).json({ success: false, message: 'Doctor details not found' });
                }
            
                const DoctorName = doctorResults[0].DoctorName; // Update this line to get the correct name
            
                res.status(200).json({ success: true, message: 'Login successful', DoctorName, pid: doctor_id });
            });
            
        });
    });
});

router.post('/cancelAppointmentDoctor', (req, res) => {
    const { appointmentId } = req.body;

    if (!appointmentId) {
        return res.status(400).json({ success: false, message: 'Appointment ID is required' });
    }

    const cancelQuery = `
        UPDATE Appointment
        SET AppointmentStatus = 'Cancelled By Doctor'
        WHERE AppointmentID = ? AND (AppointmentDate > CURDATE() OR (AppointmentDate = CURDATE() AND AppointmentStartTime > CURTIME()))
    `;

    db.query(cancelQuery, [appointmentId], (err, result) => {
        if (err) {
            console.error('Database error while cancelling appointment:', err);
            return res.status(500).json({ success: false, message: 'Failed to cancel appointment. Please try again.' });
        }

        if (result.affectedRows === 0) {
            return res.status(400).json({ success: false, message: 'Cannot cancel past appointments or invalid appointment ID.' });
        }

        // Fetch patient and doctor details for email
        const patientDoctorQuery = `
            SELECT p.Email AS patientEmail, d.DoctorName, a.AppointmentDate, a.AppointmentStartTime 
            FROM Appointment a
            JOIN Patient p ON a.PatientID = p.PatientID
            JOIN Doctor d ON a.DoctorID = d.DoctorID
            WHERE a.AppointmentID = ?
        `;

        db.query(patientDoctorQuery, [appointmentId], (err, result) => {
            if (err || result.length === 0) {
                console.error('Failed to fetch patient and doctor details for email:', err);
                return res.status(500).json({ success: true, message: 'Appointment cancelled, but failed to send email notification.' });
            }

            const { patientEmail, DoctorName, AppointmentDate, AppointmentStartTime } = result[0];

            // Send cancellation email
            sendCancellationEmail(patientEmail, DoctorName, AppointmentDate, AppointmentStartTime)
                .then(() => {
                    res.status(200).json({ success: true, message: 'Appointment cancelled and email notification sent successfully' });
                })
                .catch(error => {
                    console.error('Error sending cancellation email:', error);
                    res.status(200).json({ success: true, message: 'Appointment cancelled, but failed to send email notification.' });
                });
        });
    });
});


function sendCancellationEmail(patientEmail, doctorName, appdate, apptime) {
    return new Promise((resolve, reject) => {
        const transporter = nodemailer.createTransport({
            service: 'gmail',
            host: 'smtp.gmail.com',
            port: 465,
            secure: true, // SSL
            auth: {
                user: 'saianurag234@gmail.com', // Use environment variables in production
                pass: 'mxfh ujdv sjnn rman'
            }
        });

        const mailOptions = {
            from: '"KKVS Hospitals" <no-reply@kkvshospitals.com>',
            to: patientEmail,
            subject: 'Appointment Cancellation Notification - KKVS Hospitals',
            html: `
                <div style="font-family: 'Arial', sans-serif; color: #333; background-color: #f9f9f9; padding: 20px;">
                    <div style="background-color: #ff0000; padding: 20px; text-align: center;">
                        <h1 style="color: #fff; font-size: 24px; margin: 0;">Appointment Cancelled</h1>
                    </div>
                    <div style="background-color: #fff; padding: 20px; border-radius: 10px;">
                        <p style="font-size: 16px;">Dear Patient,</p>
                        <p style="font-size: 16px;">We regret to inform you that your appointment with <strong>Dr. ${doctorName}</strong> scheduled on <strong>${appdate}</strong> at <strong>${apptime}</strong> has been cancelled by the doctor.</p>
                        <p style="font-size: 16px;">If you need further assistance, please contact us at (+91) 9038558532 or reply to this email.</p>
                        <p style="font-size: 16px;">We apologize for the inconvenience.</p>
                        <p style="font-size: 16px;">Best Regards,</p>
                        <p style="font-size: 16px;"><strong>KKVS Hospitals Team</strong></p>
                    </div>
                    <div style="background-color: #ff0000; padding: 20px; text-align: center; font-size: 12px; color: #fff;">
                        <p>This is an automated email. Please do not reply.</p>
                        <p>&copy; 2024 KKVS Hospitals. All rights reserved.</p>
                    </div>
                </div>
            `
        };

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.error('Error sending cancellation email:', error);
                return reject(error);
            }
            resolve(info);
        });
    });
}

router.get('/getAppointmentHistoryDoctor', (req, res) => {
    const { DoctorID } = req.query;

    if (!DoctorID) {
        return res.status(400).json({ success: false, message: 'Doctor ID is required' });
    }

    const query = `
        SELECT a.AppointmentID, 
               CONCAT(p.FirstName, ' ', p.LastName) AS PatientName, 
               DATE_FORMAT(a.AppointmentDate, '%Y-%m-%d') AS AppointmentDate, 
               TIME_FORMAT(a.AppointmentStartTime, '%H:%i') AS AppointmentStartTime, 
               a.AppointmentStatus
        FROM Appointment a
        JOIN Patient p ON a.PatientID = p.PatientID
        WHERE a.DoctorID = ?
        ORDER BY a.AppointmentDate DESC, a.AppointmentStartTime DESC
    `;

    db.query(query, [DoctorID], (err, results) => {
        if (err) {
            console.error('Database error while retrieving appointment history:', err);
            return res.status(500).json({ success: false, message: 'Failed to retrieve appointment history. Please try again.' });
        }

        // Adjust for any timezone differences if needed
        results = results.map(appointment => {
            appointment.AppointmentDate = new Date(appointment.AppointmentDate).toISOString().split('T')[0];
            return appointment;
        });

        res.status(200).json({ success: true, appointments: results });
    });
});

router.get('/getPatientInformationByID', (req, res) => {
    const { PatientID } = req.query;

    if (!PatientID) {
        return res.status(400).json({ success: false, message: 'Patient ID is required' });
    }

    const query = `
        SELECT p.PatientID,
               CONCAT(p.FirstName, ' ', p.LastName) AS PatientName,
               pm.Weight,
               pm.BloodGroup,
               pm.TobaccoUsage,
               pm.AlcoholIntake,
               pm.IsDiabetic,
               pm.IsHavingBP
        FROM Patient p
        JOIN PatientMedicalBackground pm ON p.PatientID = pm.PatientID
        WHERE p.PatientID = ?
    `;

    db.query(query, [PatientID], (err, results) => {
        if (err) {
            console.error('Database error while retrieving patient information:', err);
            return res.status(500).json({ success: false, message: 'Failed to retrieve patient information. Please try again.' });
        }

        if (results.length === 0) {
            return res.status(404).json({ success: false, message: 'No patient information found for the given Patient ID.' });
        }

        res.status(200).json({ success: true, patient: results[0] });
    });
});


// Route to get prescriptions for a given PatientID
// Updated route to get prescriptions and check if the patient exists
router.get('/getPrescriptions', (req, res) => {
    const { PatientID } = req.query;

    if (!PatientID) {
        return res.status(400).json({ success: false, message: 'Patient ID is required' });
    }

    const patientQuery = `SELECT * FROM Patient WHERE PatientID = ?`;

    db.query(patientQuery, [PatientID], (err, patientResults) => {
        if (err) {
            console.error('Database error while checking patient:', err);
            return res.status(500).json({ success: false, message: 'Failed to check patient. Please try again.' });
        }

        if (patientResults.length === 0) {
            return res.status(404).json({ success: false, message: 'No patient found with the given ID.' });
        }

        const prescriptionQuery = `
            SELECT pr.PrescriptionID,
                   m.Name AS MedicineName,
                   pr.MedicineDosage,
                   pr.MedicineDuration,
                   pr.NoOfTablets,
                   pr.PrescribedDate,
                   pr.PrescriptionStatus
            FROM Prescription pr
            JOIN Medicine m ON pr.MedicineID = m.MedicineID
            WHERE pr.PatientID = ?
            ORDER BY pr.PrescribedDate DESC
        `;

        db.query(prescriptionQuery, [PatientID], (err, prescriptionResults) => {
            if (err) {
                console.error('Database error while retrieving prescriptions:', err);
                return res.status(500).json({ success: false, message: 'Failed to retrieve prescriptions. Please try again.' });
            }

            res.status(200).json({ success: true, prescriptions: prescriptionResults });
        });
    });
});



// Route to discontinue the latest prescription for a patient
router.post('/discontinuePrescription', (req, res) => {
    const { prescriptionId } = req.body;

    if (!prescriptionId) {
        return res.status(400).json({ success: false, message: 'Prescription ID is required' });
    }

    const query = `
        UPDATE Prescription
        SET PrescriptionStatus = 'Discontinued'
        WHERE PrescriptionID = ?
    `;

    db.query(query, [prescriptionId], (err, results) => {
        if (err) {
            console.error('Database error while discontinuing prescription:', err);
            return res.status(500).json({ success: false, message: 'Failed to discontinue prescription. Please try again.' });
        }

        if (results.affectedRows === 0) {
            return res.status(404).json({ success: false, message: 'Prescription not found.' });
        }

        res.status(200).json({ success: true, message: 'Prescription discontinued successfully.' });
    });
});


// Route to add a new prescription for a patient
router.post('/addPrescription', (req, res) => {
    const { patientId, medicineId, medicineDosage, medicineDuration, noOfTablets, prescribedDate, doctorId } = req.body;

    if (!patientId || !medicineId || !medicineDosage || !medicineDuration || !noOfTablets ||!prescribedDate || !doctorId) {
        return res.status(400).json({ success: false, message: 'All fields are required' });
    }

    // Format the date to MySQL format
    const formattedDate = moment(prescribedDate).format('YYYY-MM-DD HH:mm:ss');

    // Query to get the latest appointment ID for the patient
    const getLatestAppointmentQuery = `
        SELECT AppointmentID FROM Appointment
        WHERE PatientID = ?
        ORDER BY AppointmentDate DESC, AppointmentStartTime DESC
        LIMIT 1
    `;

    db.query(getLatestAppointmentQuery, [patientId], (err, appointmentResults) => {
        if (err) {
            console.error('Database error while retrieving latest appointment:', err);
            return res.status(500).json({ success: false, message: 'Failed to retrieve latest appointment. Please try again.' });
        }

        const appointmentId = appointmentResults.length > 0 ? appointmentResults[0].AppointmentID : null;

        // Query to insert a new prescription
        const insertPrescriptionQuery = `
            INSERT INTO Prescription (PatientID, DoctorID, MedicineID, MedicineDosage, MedicineDuration,noOfTablets,PrescribedDate, PrescriptionStatus, AppointmentID)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'Active', ?)
        `;

        db.query(insertPrescriptionQuery, [patientId, doctorId, medicineId, medicineDosage, medicineDuration,noOfTablets, formattedDate, appointmentId], (err, results) => {
            if (err) {
                console.error('Database error while adding prescription:', err);
                return res.status(500).json({ success: false, message: 'Failed to add prescription. Please try again.' });
            }

            res.status(201).json({ success: true, message: 'Prescription added successfully.' });
        });
    });
});

// Route to get all medicines
router.get('/getMedicines', (req, res) => {
    const query = 'SELECT MedicineID, Name AS name, manufacturer_name FROM Medicine';
    
    db.query(query, (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ success: false, message: 'Database query error' });
        }

        if (results.length === 0) {
            return res.status(404).json({ success: false, message: 'No medicines found' });
        }

        res.json({ success: true, medicines: results });
    });
});




router.post('/adminlogin', (req, res) => {
    console.log(req.body);
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ success: false, message: 'Username and password are required' });
    }

    db.query('SELECT adminpassword FROM AdminLogin WHERE username = ?', [username], (err, results) => {
        if (err) {
            console.error("Database query error: ", err);
            return res.status(500).json({ success: false, message: 'Database query error' });
        }

        if (results.length === 0) {
            return res.status(400).json({ success: false, message: 'Username not registered' });
        }

        const dbPassword = results[0].adminpassword;

        bcrypt.compare(password, dbPassword, (err, isMatch) => {
            if (err) {
                console.error("Bcrypt comparison error: ", err);
                return res.status(500).json({ success: false, message: 'Password comparison error' });
            }

            if (!isMatch) {
                return res.status(400).json({ success: false, message: 'Password incorrect' });
            }

            return res.status(200).json({ success: true, message: 'Login successful' });
        });
    });
});

// Route to fetch all departments
router.get('/getdepartments', (req, res) => {
    db.query('SELECT * FROM DoctorDepartment', (err, results) => {
        if (err) {
            console.error("Database query error: ", err);
            return res.status(500).json({ success: false, message: 'Database query error' });
        }

        res.status(200).json({ success: true, departments: results });
    });
});


router.post('/registerdoctor', (req, res) => {
    const { 
        'doctor-name': doctorName, 
        'doctor-dob': doctorDOB, 
        'doctor-gender': doctorGender, 
        'doctor-qualification': doctorQualification, 
        'doctor-department': doctorDepartmentID, 
        'doctor-experience': doctorExperience,
        'doctor-consultation-fee': doctorConsultationFee // Capture the new field
    } = req.body;

    // Check for missing fields
    if (!doctorName || !doctorDOB || !doctorGender || 
        !doctorQualification || !doctorDepartmentID || !doctorExperience || !doctorConsultationFee) {
        return res.status(400).json({ success: false, message: 'All fields are required' });
    }

    // First, insert the doctor into the Doctor table
    const newDoctor = {
        DoctorName: doctorName,
        DateOfBirth: doctorDOB,
        DoctorGender: doctorGender,
        DoctorQualification: doctorQualification,
        DoctorDepartmentID: doctorDepartmentID,
        YearOfExperience: doctorExperience
    };

    db.query('INSERT INTO Doctor SET ?', newDoctor, (err, result) => {
        if (err) {
            console.error("Database insertion error: ", err);
            return res.status(500).json({ success: false, message: 'Database insertion error' });
        }

        const doctorID = result.insertId; // Assuming the DoctorID is an auto-increment field
        
        // Insert the consultation fee into the DoctorConsultantFee table
        const consultantFeeData = {
            DoctorID: doctorID,
            FeeAmount: doctorConsultationFee
        };

        db.query('INSERT INTO DoctorConsultantFee SET ?', consultantFeeData, (err, result) => {
            if (err) {
                console.error("Database insertion error: ", err);
                return res.status(500).json({ success: false, message: 'Database insertion error in fee table' });
            }

            res.status(200).json({ success: true, message: 'Doctor registered successfully' });
        });
    });
});


router.get('/checkroomavailability', (req, res) => {
    const { type } = req.query;

    if (!type) {
        return res.status(400).json({ success: false, message: 'Room type is required' });
    }

    const query = `
        SELECT RoomNumber 
        FROM Room 
        INNER JOIN RoomType ON Room.RoomTypeID = RoomType.RoomTypeID 
        WHERE RoomType.TypeName = ? AND Room.Status = 'Available'
    `;

    db.query(query, [type], (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ success: false, message: 'Database query error' });
        }

        const roomNumbers = results.map(row => row.RoomNumber);
        res.json({ success: true, count: roomNumbers.length, roomNumbers });
    });
});

// Get Available Room Numbers for a Specific Room Type
router.get('/getavailablerooms', (req, res) => {
    const { type } = req.query;

    if (!type) {
        return res.status(400).json({ success: false, message: 'Room type is required' });
    }

    const query = `
        SELECT RoomNumber 
        FROM Room 
        INNER JOIN RoomType ON Room.RoomTypeID = RoomType.RoomTypeID 
        WHERE RoomType.TypeName = ? AND Room.Status = 'Available'
    `;

    db.query(query, [type], (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ success: false, message: 'Database query error' });
        }

        const roomNumbers = results.map(row => row.RoomNumber);
        res.json({ success: true, roomNumbers });
    });
});

// Admit Patient
router.post('/admitpatient', (req, res) => {
    console.log(req.body);
    const { patient_id_admit, admit_room_number, admit_date } = req.body;

    // Validate input
    if (!patient_id_admit || !admit_room_number || !admit_date) {
        return res.status(400).json({ success: false, message: 'All fields are required' });
    }

    // Check if the patient exists in the database
    const patientExistsQuery = `SELECT * FROM Patient WHERE PatientID = ?`;
    
    db.query(patientExistsQuery, [patient_id_admit], (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ success: false, message: 'Database query error' });
        }

        if (results.length === 0) {
            return res.status(404).json({ success: false, message: 'Patient ID does not exist' });
        }

        // Check if the patient is already admitted and not discharged
        const checkQuery = `
            SELECT * 
            FROM InPatient 
            WHERE PatientID = ? AND DateOfDischarge IS NULL
        `;

        db.query(checkQuery, [patient_id_admit], (err, results) => {
            if (err) {
                console.error('Database query error:', err);
                return res.status(500).json({ success: false, message: 'Database query error' });
            }

            if (results.length > 0) {
                // Patient is already admitted and not discharged
                return res.status(400).json({ success: false, message: 'Patient is already admitted and not discharged.' });
            }

            // Admit the patient
            const admitQuery = `
                INSERT INTO InPatient (PatientID, RoomNumber, DateOfAdmission)
                VALUES (?, ?, ?)
            `;

            db.query(admitQuery, [patient_id_admit, admit_room_number, admit_date], (err, result) => {
                if (err) {
                    console.error('Database insertion error:', err);
                    return res.status(500).json({ success: false, message: 'Database insertion error' });
                }

                const inPatientID = result.insertId;  // Get the newly created InPatientID

                // Update room status to 'Occupied'
                db.query('UPDATE Room SET Status = ? WHERE RoomNumber = ?', ['Occupied', admit_room_number], (err, result) => {
                    if (err) {
                        console.error('Error updating room status:', err);
                        return res.status(500).json({ success: false, message: 'Error updating room status' });
                    }

                    res.json({ success: true, message: 'Patient admitted successfully', inPatientID });
                });
            });
        });
    });
});


// Discharge a Patient
router.post('/dischargepatient', (req, res) => {
    const { patient_id_discharge, inpatient_id_discharge, discharge_date } = req.body;

    // Validate input
    if (!patient_id_discharge || !inpatient_id_discharge || !discharge_date) {
        return res.status(400).json({ success: false, message: 'All fields are required' });
    }

    // Check if the patient exists in the database
    const patientExistsQuery = `SELECT * FROM Patient WHERE PatientID = ?`;
    
    db.query(patientExistsQuery, [patient_id_discharge], (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ success: false, message: 'Database query error' });
        }

        if (results.length === 0) {
            return res.status(404).json({ success: false, message: 'Patient ID does not exist' });
        }

        // Validate In-Patient ID and check if the patient is still admitted
        const validateQuery = `
            SELECT i.*, r.RoomRent 
            FROM InPatient i
            JOIN Room rt ON i.RoomNumber = rt.RoomNumber
            JOIN RoomType r ON rt.RoomTypeID = r.RoomTypeID
            WHERE i.InPatientID = ? AND i.PatientID = ? AND i.DateOfDischarge IS NULL
        `;

        db.query(validateQuery, [inpatient_id_discharge, patient_id_discharge], (err, results) => {
            if (err) {
                console.error('Database query error:', err);
                return res.status(500).json({ success: false, message: 'Database query error' });
            }

            if (results.length === 0) {
                return res.status(400).json({ success: false, message: 'Patient is not Admitted or InPatientID is invalid' });
            }

            const admissionDate = new Date(results[0].DateOfAdmission);
            const dischargeDate = new Date(discharge_date);
            const daysStayed = Math.ceil((dischargeDate - admissionDate) / (1000 * 60 * 60 * 24)); // Calculate number of days
            const roomRent = results[0].RoomRent;
            const totalRoomRent = daysStayed * roomRent;

            // Discharge the patient and update discharge date
            const dischargeQuery = `
                UPDATE InPatient 
                SET DateOfDischarge = ? 
                WHERE InPatientID = ?
            `;

            db.query(dischargeQuery, [discharge_date, inpatient_id_discharge], (err, result) => {
                if (err) {
                    console.error('Database update error:', err);
                    return res.status(500).json({ success: false, message: 'Database update error' });
                }

                // Update room status to 'Available'
                db.query('UPDATE Room SET Status = ? WHERE RoomNumber = ?', ['Available', results[0].RoomNumber], (err, result) => {
                    if (err) {
                        console.error('Error updating room status:', err);
                        return res.status(500).json({ success: false, message: 'Error updating room status' });
                    }

                    // Insert into RoomRent table with Stay_Duration and TotalRoomRent
                    const insertRoomRentQuery = `
                        INSERT INTO RoomRent (InPatientID, PatientID, Stay_Duration, TotalRoomRent) 
                        VALUES (?, ?, ?, ?)
                    `;

                    db.query(insertRoomRentQuery, [inpatient_id_discharge, patient_id_discharge, daysStayed, totalRoomRent], (err, result) => {
                        if (err) {
                            console.error('Error inserting into RoomRent:', err);
                            return res.status(500).json({ success: false, message: 'Error inserting into RoomRent' });
                        }

                        res.json({ success: true, message: 'Patient discharged successfully, Room Rent recorded' });
                    });
                });
            });
        });
    });
});




// Check Patient Status
router.get('/checkpatientstatus', (req, res) => {
    console.log(req.query);
    console.log(req.query.patient_id);
    const patientId = req.query.patient_id;

    // Validate input
    if (!patientId) {
        return res.status(400).json({ success: false, message: 'Patient ID is required' });
    }

    // Check if the patient exists in the database
    const patientExistsQuery = `SELECT * FROM Patient WHERE PatientID = ?`;
    
    db.query(patientExistsQuery, [patientId], (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ success: false, message: 'Database query error' });
        }

        if (results.length === 0) {
            return res.status(404).json({ success: false, message: 'Patient ID does not exist' });
        }

        // Query to check if patient is already admitted and not discharged
        const checkQuery = `
            SELECT * 
            FROM InPatient 
            WHERE PatientID = ? AND DateOfDischarge IS NULL
        `;

        db.query(checkQuery, [patientId], (err, results) => {
            if (err) {
                console.error('Database query error:', err);
                return res.status(500).json({ success: false, message: 'Database query error' });
            }

            if (results.length > 0) {
                // Patient is already admitted and not discharged
                return res.json({ success: true, isAdmitted: true });
            }

            // Patient is not currently admitted
            res.json({ success: true, isAdmitted: false });
        });
    });
});

router.post('/addmedicine', (req, res) => {
    const { medicine_name, manufacturer_name, quantity, price } = req.body;

    if (!medicine_name || quantity === undefined || price === undefined) {
        return res.status(400).json({ success: false, message: 'All fields are required' });
    }

    const insertMedicineQuery = 
        'INSERT INTO Medicine (Name, manufacturer_name, Price) VALUES (?, ?, ?)';

    db.query(insertMedicineQuery, [medicine_name, manufacturer_name, price], (err, result) => {
        if (err) {
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(409).json({ success: false, message: 'Medicine with this name or manufacturer already exists.' });
            }
            console.error('Database insert error:', err);
            return res.status(500).json({ success: false, message: 'Database insert error' });
        }

        const medicineID = result.insertId;
        const insertPharmacyQuery = 
            'INSERT INTO Pharmacy (MedicineID, QuantityAvailable, LastRestocked) VALUES (?, ?, CURDATE())';

        db.query(insertPharmacyQuery, [medicineID, quantity], (err, result) => {
            if (err) {
                console.error('Database insert error:', err);
                return res.status(500).json({ success: false, message: 'Database insert error' });
            }

            res.json({ success: true, message: `Medicine ${medicine_name} added successfully` });
        });
    });
});

router.get('/getmedicinestock', (req, res) => {
    const medicineName = req.query.name;

    if (!medicineName) {
        return res.status(400).json({ success: false, message: 'Medicine name is required' });
    }

    const query = `
        SELECT m.Name, p.QuantityAvailable, m.manufacturer_name, m.Price 
        FROM Medicine m 
        LEFT JOIN Pharmacy p ON m.MedicineID = p.MedicineID 
        WHERE m.Name = ?
    `;

    db.query(query, [medicineName], (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ success: false, message: 'Database query error' });
        }

        if (results.length === 0) {
            return res.status(404).json({ success: false, message: 'Medicine not found' });
        }

        let stockInfo = results[0];
        if (stockInfo.QuantityAvailable === null) {
            stockInfo.QuantityAvailable = 'Out of Stock';
        }

        res.json({ success: true, stockInfo });
    });
});


router.post('/updatemedicinestock', (req, res) => {
    const { medicine_name, type_of_update, quantity } = req.body;

    // Ensure quantity is treated as an integer
    const parsedQuantity = parseInt(quantity, 10);

    if (!medicine_name || !type_of_update || isNaN(parsedQuantity) || parsedQuantity < 0) {
        return res.status(400).json({ success: false, message: 'All fields are required and quantity must be a valid, non-negative number' });
    }

    const fetchQuery = `
        SELECT p.QuantityAvailable, m.MedicineID 
        FROM Medicine m 
        LEFT JOIN Pharmacy p ON m.MedicineID = p.MedicineID 
        WHERE m.Name = ?
    `;
    
    db.query(fetchQuery, [medicine_name], (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ success: false, message: 'Database query error' });
        }

        if (results.length === 0) {
            return res.status(404).json({ success: false, message: 'Medicine not found' });
        }

        let { QuantityAvailable, MedicineID } = results[0];
        QuantityAvailable = QuantityAvailable === null ? 0 : parseInt(QuantityAvailable, 10); // Handle null values

        if (type_of_update === 'Sales') {
            if (QuantityAvailable === 0) {
                return res.status(400).json({ success: false, message: 'Cannot process sales. Medicine is out of stock.' });
            }
            if (parsedQuantity > QuantityAvailable) {
                return res.status(400).json({ success: false, message: 'Selling quantity exceeds available stock' });
            }
            QuantityAvailable -= parsedQuantity;
        } else if (type_of_update === 'Re-Stock') {
            QuantityAvailable += parsedQuantity;
        }

        const updateQuery = 'UPDATE Pharmacy SET QuantityAvailable = ? WHERE MedicineID = ?';
        db.query(updateQuery, [QuantityAvailable, MedicineID], (err, result) => {
            if (err) {
                console.error('Database update error:', err);
                return res.status(500).json({ success: false, message: 'Database update error' });
            }

            res.json({ success: true, message: 'Medicine stock updated successfully' });
        });
    });
});




router.get('/getmedicinenames', (req, res) => {
    const query = 'SELECT Name, manufacturer_name FROM Medicine';

    db.query(query, (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ success: false, message: 'Database query error' });
        }

        if (results.length === 0) {
            return res.status(404).json({ success: false, message: 'No medicines found' });
        }

        // Ensure the correct mapping of results
        const medicineNames = results.map(row => ({
            name: row.Name,
            manufacturer: row.manufacturer_name
        }));

        res.json({ success: true, medicineNames });
    });
});


router.get('/generatebill', (req, res) => {
    const { patientId } = req.query;

    if (!patientId) {
        return res.status(400).json({ success: false, message: 'Patient ID is required' });
    }

    // Example queries and logic
    const billDetails = {};

    // Fetch the latest appointment
    const appointmentQuery = `
        SELECT AppointmentID, DoctorID, AppointmentDate 
        FROM Appointment 
        WHERE PatientID = ? 
        ORDER BY AppointmentDate DESC 
        LIMIT 1
    `;

    db.query(appointmentQuery, [patientId], (err, appointments) => {
        if (err || appointments.length === 0) {
            return res.status(500).json({ success: false, message: 'Error fetching appointment data' });
        }

        const appointment = appointments[0];
        billDetails.patientId = patientId;

        // Fetch doctor consultation fee
        const doctorFeeQuery = `
            SELECT FeeAmount 
            FROM DoctorConsultantFee 
            WHERE DoctorID = ?
        `;
        
        db.query(doctorFeeQuery, [appointment.DoctorID], (err, doctorFeeResults) => {
            if (err || doctorFeeResults.length === 0) {
                return res.status(500).json({ success: false, message: 'Error fetching doctor fee' });
            }
            
            billDetails.consultationFee = doctorFeeResults[0].ConsultationFee;

            // Fetch any ongoing prescription
            const prescriptionQuery = `
                SELECT m.Name, m.Price, p.MedicineDosage, p.MedicineDuration 
                FROM Prescription p 
                JOIN Medicine m ON p.MedicineID = m.MedicineID 
                WHERE p.PatientID = ? 
                AND p.PrescriptionStatus = 'Active'
            `;

            db.query(prescriptionQuery, [patientId], (err, prescriptions) => {
                if (err) {
                    return res.status(500).json({ success: false, message: 'Error fetching prescriptions' });
                }

                let prescriptionCharges = 0;
                prescriptions.forEach(prescription => {
                    prescriptionCharges += prescription.Price; // Simplified pricing calculation
                });

                billDetails.prescriptionCharges = prescriptionCharges;

                // Fetch inpatient details if the patient is admitted
                const inpatientQuery = `
                    SELECT i.InPatientID, r.RoomRent, DATEDIFF(CURDATE(), i.DateOfAdmission) AS NumberOfDays 
                    FROM InPatient i 
                    JOIN Room r ON i.RoomNumber = r.RoomNumber 
                    JOIN RoomType rt ON r.RoomTypeID = rt.RoomTypeID 
                    WHERE i.PatientID = ? 
                    AND i.DateOfDischarge IS NULL
                `;

                db.query(inpatientQuery, [patientId], (err, inpatients) => {
                    if (err) {
                        return res.status(500).json({ success: false, message: 'Error fetching inpatient data' });
                    }

                    if (inpatients.length > 0) {
                        const inpatient = inpatients[0];
                        billDetails.roomRent = inpatient.RoomRent * inpatient.NumberOfDays;
                    } else {
                        billDetails.roomRent = 0;
                    }

                    // Calculate the total bill
                    billDetails.totalBill = billDetails.consultationFee + billDetails.prescriptionCharges + (billDetails.roomRent || 0);

                    // Return the bill details
                    res.json({ success: true, billDetails });
                });
            });
        });
    });
});


router.get('/generateBill', (req, res) => {
    const patientId = req.query.patientId;

    // Step 1: Check if the patient exists
    const patientQuery = 'SELECT * FROM Patient WHERE PatientID = ?';
    db.query(patientQuery, [patientId], (err, patientResults) => {
        if (err || patientResults.length === 0) {
            return res.status(404).json({ success: false, message: 'Patient not found' });
        }

        // Step 2: Check if the patient is admitted
        const inpatientQuery = `
            SELECT * FROM InPatient 
            WHERE PatientID = ? 
            ORDER BY DateOfAdmission DESC 
            LIMIT 1
        `;
        db.query(inpatientQuery, [patientId], (err, inpatientResults) => {
            let isCurrentlyAdmitted = false;
            let roomCost = 0;
            let stayDuration = 0;

            if (err) {
                return res.status(500).json({ success: false, message: 'Database error while checking admission' });
            }

            if (inpatientResults.length > 0) {
                const latestAdmission = inpatientResults[0];
                const dateOfAdmission = new Date(latestAdmission.DateOfAdmission);
                const dateOfDischarge = latestAdmission.DateOfDischarge ? new Date(latestAdmission.DateOfDischarge) : new Date();
                stayDuration = Math.ceil((dateOfDischarge - dateOfAdmission) / (1000 * 60 * 60 * 24));
                isCurrentlyAdmitted = !latestAdmission.DateOfDischarge;

                // Step 3: Calculate room cost if admitted
                const roomCostQuery = `
                    SELECT RT.RoomRent 
                    FROM RoomType RT 
                    JOIN Room R ON R.RoomTypeID = RT.RoomTypeID 
                    WHERE R.RoomNumber = ?
                `;
                db.query(roomCostQuery, [latestAdmission.RoomNumber], (err, roomResults) => {
                    if (err || roomResults.length === 0) {
                        return res.status(500).json({ success: false, message: 'Error calculating room cost' });
                    }
                    const roomRent = roomResults[0].RoomRent;
                    roomCost = roomRent * stayDuration;
                    calculateBill(patientId, isCurrentlyAdmitted, roomCost, stayDuration);
                });
            } else {
                // Patient is not currently admitted
                calculateBill(patientId, isCurrentlyAdmitted, roomCost, stayDuration);
            }
        });
    });

    // Function to calculate bill based on current admission status
    function calculateBill(patientId, isCurrentlyAdmitted, roomCost, stayDuration) {
        let consultantFee = 0;
        let medicineCost = 0;

        // Step 4: Calculate consultant fees for all appointments
        const consultantFeeQuery = `
            SELECT SUM(FeeAmount) AS totalConsultantFee 
            FROM Appointment A 
            JOIN DoctorConsultantFee DF ON A.DoctorID = DF.DoctorID 
            WHERE A.PatientID = ? AND A.AppointmentStatus = 'Scheduled'
        `;
        db.query(consultantFeeQuery, [patientId], (err, feeResults) => {
            if (err) {
                return res.status(500).json({ success: false, message: 'Error calculating consultant fee' });
            }
            consultantFee = feeResults[0].totalConsultantFee || 0;

            // Step 5: Calculate medicine costs for ongoing prescriptions
            const medicineCostQuery = `
                SELECT SUM(M.Price * P.noOfTablets) AS totalMedicineCost
                FROM Prescription P
                JOIN Medicine M ON P.MedicineID = M.MedicineID
                WHERE P.PatientID = ? AND P.PrescriptionStatus = 'Active'
            `;
            db.query(medicineCostQuery, [patientId], (err, medicineResults) => {
                if (err) {
                    return res.status(500).json({ success: false, message: 'Error calculating medicine cost' });
                }
                medicineCost = medicineResults[0].totalMedicineCost || 0;

                // Step 6: Sum up all costs
                const totalBill = consultantFee + roomCost + medicineCost;

                res.json({
                    success: true,
                    billDetails: {
                        patientId,
                        consultantFee,
                        roomCost,
                        medicineCost,
                        totalBill,
                        isCurrentlyAdmitted,
                        stayDuration
                    }
                });
            });
        });
    }
});

router.get('/getconsultationfee', (req, res) => {
    const doctorId = req.query.doctor_id;

    // Assuming you are using some ORM or direct SQL queries
    db.query('SELECT FeeAmount FROM DoctorConsultantFee WHERE DoctorID = ?', [doctorId], (error, results) => {
        if (error) {
            console.error('Error fetching consultation fee:', error);
            return res.json({ success: false, message: 'Failed to fetch consultation fee.' });
        }

        if (results.length > 0) {
            return res.json({ success: true, fee: results[0].FeeAmount });
        } else {
            return res.json({ success: false, message: 'Consultation fee not found.' });
        }
    });
});


router.get('/getBills', (req, res) => {
    const patientId = req.query.patientId; // Get patientId from query parameter

    // Check if patientId is provided
    if (!patientId) {
        return res.status(400).json({ success: false, message: 'Patient ID is required' });
    }

    // Query to fetch bills for the given patient ID
    const fetchBillsQuery = `
        SELECT * FROM RoomRent WHERE PatientID = ?
    `;

    db.query(fetchBillsQuery, [patientId], (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ success: false, message: 'Failed to fetch room bills' });
        }

        // Respond with fetched bills
        res.json({ success: true, bills: results });
    });
});

// Fetch available lab tests
router.get('/getlabtests', (req, res) => {
    const getLabTestsQuery = 'SELECT TestID, Name FROM LabTest';

    db.query(getLabTestsQuery, (err, results) => {
        if (err) {
            console.error('Error fetching lab tests:', err);
            return res.status(500).json({ success: false, message: 'Failed to fetch lab tests' });
        }
        res.status(200).json({ success: true, labTests: results });
    });
});

// Book a Lab Test

router.post('/booklabtest', (req, res) => {
    const { patient_id, referred_doctor_id, test_id, test_datetime } = req.body;

    if (!patient_id || !referred_doctor_id || !test_id || !test_datetime) {
        return res.status(400).json({ success: false, message: 'All fields are required' });
    }

    // Validate PatientID and DoctorID
    const validateQuery = `
        SELECT 
            (SELECT COUNT(*) FROM Patient WHERE PatientID = ?) AS patientExists, 
            (SELECT COUNT(*) FROM Doctor WHERE DoctorID = ?) AS doctorExists
    `;

    db.query(validateQuery, [patient_id, referred_doctor_id], (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ success: false, message: 'Database query error' });
        }

        const { patientExists, doctorExists } = results[0];

        if (!patientExists) {
            return res.status(400).json({ success: false, message: 'Invalid Patient ID' });
        }

        if (!doctorExists) {
            return res.status(400).json({ success: false, message: 'Invalid Doctor ID' });
        }

        // If validations pass, insert the lab test booking
        const bookLabTestQuery = `
            INSERT INTO Lab (PatientID, ReferredDoctorID, TestID, TestDateTime)
            VALUES (?, ?, ?, ?)
        `;

        db.query(bookLabTestQuery, [patient_id, referred_doctor_id, test_id, test_datetime], (err, result) => {
            if (err) {
                console.error('Error booking lab test:', err);
                return res.status(500).json({ success: false, message: 'Failed to book lab test. Please try again.' });
            }

            res.status(200).json({ success: true, message: 'Lab test booked successfully' });
        });
    });
});


// Route to fetch Lab Bills
router.get('/getLabBills', (req, res) => {
    const patientId = req.query.patientId;

    const query = patientId 
        ? `SELECT * FROM LabBill WHERE PatientID = ?`
        : `SELECT * FROM LabBill`;

    const params = patientId ? [patientId] : [];

    db.query(query, params, (err, results) => {
        if (err) {
            console.error('Error fetching lab bills:', err);
            return res.status(500).json({ success: false, message: 'Error fetching lab bills' });
        }

        res.json({ success: true, bills: results });
    });
});

router.post('/generateLabBill', (req, res) => {
    const { patientId } = req.body;

    // Check if the patient exists
    const checkPatientQuery = `SELECT COUNT(*) AS patientExists FROM Patient WHERE PatientID = ?`;

    db.query(checkPatientQuery, [patientId], (err, result) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ success: false, message: 'Database query error' });
        }

        if (result[0].patientExists === 0) {
            return res.status(200).json({ success: false, message: 'Patient does not exist' });
        }

        // Calculate the total price of lab tests with BillStatus 'Not Generated'
        const getLabTestsQuery = `
            SELECT SUM(LT.Price) AS totalLabPrice
            FROM Lab L
            JOIN LabTest LT ON L.TestID = LT.TestID
            WHERE L.PatientID = ? AND L.BillStatus = 'Not Generated'
        `;

        db.query(getLabTestsQuery, [patientId], (err, results) => {
            if (err) {
                console.error('Error fetching lab tests:', err);
                return res.status(500).json({ success: false, message: 'Error fetching lab tests' });
            }

            const totalLabPrice = results[0].totalLabPrice;

            // If no lab tests found with 'Not Generated' status
            if (!totalLabPrice) {
                return res.status(200).json({ success: true, message: 'No bill to generate' });
            }

            // Insert the new lab bill into the LabBill table
            const insertLabBillQuery = `
                INSERT INTO LabBill (PatientID, TotalLabBill)
                VALUES (?, ?)
            `;

            db.query(insertLabBillQuery, [patientId, totalLabPrice], (err, result) => {
                if (err) {
                    console.error('Error inserting lab bill:', err);
                    return res.status(500).json({ success: false, message: 'Failed to generate lab bill' });
                }

                // Update the BillStatus of the lab tests to 'Generated'
                const updateLabTestsQuery = `
                    UPDATE Lab
                    SET BillStatus = 'Generated'
                    WHERE PatientID = ? AND BillStatus = 'Not Generated'
                `;

                db.query(updateLabTestsQuery, [patientId], (err, result) => {
                    if (err) {
                        console.error('Error updating lab tests:', err);
                        return res.status(500).json({ success: false, message: 'Failed to update lab tests status' });
                    }

                    res.json({ success: true, message: 'Lab bill generated successfully' });
                });
            });
        });
    });
});

router.get('/getLabTestsInProgress/:patientId', (req, res) => {
    const patientId = req.params.patientId;

    // Check if the patient exists
    const checkPatientQuery = `SELECT COUNT(*) AS patientExists FROM Patient WHERE PatientID = ?`;

    db.query(checkPatientQuery, [patientId], (err, result) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ success: false, message: 'Database query error' });
        }

        if (result[0].patientExists === 0) {
            return res.status(200).json({ success: false, message: 'Patient does not exist' });
        }

        // Fetch lab tests in progress for the patient
        const query = `
            SELECT Lab.LabRecordID, Lab.TestID, Lab.TestDateTime, LabTest.Name AS TestName
            FROM Lab 
            JOIN LabTest ON Lab.TestID = LabTest.TestID
            WHERE Lab.PatientID = ? AND Lab.TestStatus = 'In Progress'
        `;
        
        db.query(query, [patientId], (err, results) => {
            if (err) {
                console.error('Error fetching lab tests:', err);
                return res.status(500).json({ success: false, message: 'Database error' });
            }

            if (results.length === 0) {
                return res.status(200).json({ success: false, message: 'No lab tests in progress for this patient' });
            }

            res.json({ success: true, labTests: results });
        });
    });
});


module.exports = router;
