const express = require('express');
const sqldb = require('../config'); // MySQL connection
const multer = require('multer');
const { MongoClient, GridFSBucket } = require('mongodb');
const { ObjectId } = require('mongodb');
const router = express.Router();
const mongoURI = 'mongodb://localhost:27017';

// Setup MongoDB Connection
let db, gfs;
MongoClient.connect(mongoURI, { serverSelectionTimeoutMS: 10000 }) // 10 seconds timeout for server selection
    .then(client => {
        db = client.db('Hospital_Management');
        gfs = new GridFSBucket(db, {
            bucketName: 'labReports'
        });
        console.log('Successfully connected to MongoDB');
    })
    .catch(err => console.error('Failed to connect to MongoDB', err));

// Configure multer for file upload
const storage = multer.memoryStorage();
const upload = multer({ storage });

// Route for uploading lab test results
router.post('/uploadLabResult', upload.single('labResult'), (req, res) => {
    console.log('Received request to upload lab result');
    console.log('Request body:', req.body);

    const { patientId, labRecordId, testName, testDatetime } = req.body;

    if (!req.file) {
        console.error('No file uploaded in the request');
        return res.status(400).json({ success: false, message: 'No file uploaded' });
    }

    try {
        const uploadStream = gfs.openUploadStream(req.file.originalname, {
            metadata: {
                patientId: parseInt(patientId),
                labRecordId: parseInt(labRecordId),
                testName,
                testDatetime,
                contentType: req.file.mimetype  // Ensure this is set correctly based on the uploaded file's mimetype
            }
        });
        

        uploadStream.end(req.file.buffer);

        uploadStream.on('finish', () => {
            const fileId = uploadStream.id;
            console.log('File uploaded to GridFS with ID:', fileId);

            // MongoDB insertion successful, now execute MySQL query
            const updateQuery = `
                UPDATE Lab 
                SET TestStatus = 'Completed' 
                WHERE LabRecordID = ?
            `;

            console.log('Running SQL query:', updateQuery, 'with LabRecordID:', labRecordId);

            // Execute the SQL query similarly to how it's done in patientlogin
            sqldb.query(updateQuery, [labRecordId], (error, results) => {
                if (error) {
                    console.error('Error updating test status in MySQL:', error);
                    return res.status(500).json({ success: false, message: 'Error updating test status in MySQL' });
                }

                console.log('Test status updated to Completed in MySQL:', results);
                return res.status(200).json({ success: true, message: 'Lab result uploaded and test status updated successfully' });
            });
        });

        uploadStream.on('error', (err) => {
            console.error('Error uploading file to GridFS:', err);
            return res.status(500).json({ success: false, message: 'File upload failed' });
        });
    } catch (error) {
        console.error('Unexpected error during file upload:', error);
        return res.status(500).json({ success: false, message: 'An unexpected error occurred' });
    }
});

router.get('/lab-reports', async (req, res) => {
    const { patientId } = req.query;
    const currentDate = new Date();
    const past10DaysDate = new Date(currentDate.getTime() - (10 * 24 * 60 * 60 * 1000)); // 10 days back

    // First, check if the patient exists
    const checkPatientQuery = `SELECT COUNT(*) AS patientExists FROM Patient WHERE PatientID = ?`;

    sqldb.query(checkPatientQuery, [patientId], (err, result) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ success: false, message: 'Database query error' });
        }

        // If patient doesn't exist, return the appropriate message
        if (result[0].patientExists === 0) {
            return res.status(200).json({ success: false, message: 'Patient does not exist' });
        }

        // If patient exists, proceed with fetching lab reports
        try {
            const query = `
                SELECT LabRecordID, TestID, TestDateTime, TestStatus
                FROM Lab
                WHERE PatientID = ? AND TestStatus = 'Completed' AND TestDateTime >= ?
            `;
            sqldb.query(query, [patientId, past10DaysDate], async (err, results) => {
                if (err) {
                    return res.status(500).json({ success: false, message: 'Failed to fetch tests' });
                }

                const labRecords = results.map(row => row.LabRecordID);

                const tests = await db.collection('labReports.files').find({
                    'metadata.patientId': parseInt(patientId),
                    'metadata.labRecordId': { $in: labRecords }
                }).toArray();

                res.json({ success: true, tests });
            });
        } catch (error) {
            console.error('Error fetching lab reports:', error);
            return res.status(500).json({ success: false, message: 'Failed to fetch lab reports' });
        }
    });
});


router.get('/lab-report/:testId', async (req, res) => {
    const { testId } = req.params;

    try {
        // Validate if testId is a valid ObjectId
        if (!ObjectId.isValid(testId)) {
            return res.status(400).json({ success: false, message: 'Invalid test ID' });
        }

        const fileDoc = await db.collection('labReports.files').findOne({ _id: new ObjectId(testId) });

        if (!fileDoc) {
            return res.status(404).json({ success: false, message: 'Lab report not found' });
        }

        // Check if the file is a PDF or an image
        const reportType = fileDoc.filename.endsWith('.pdf') ? 'pdf' : 'image';

        res.json({ success: true, reportType, fileId: fileDoc._id });
    } catch (error) {
        console.error('Error fetching lab report:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch lab report' });
    }
});


router.get('/lab-report/file/:fileId', (req, res) => {
    const { fileId } = req.params;

    if (!ObjectId.isValid(fileId)) {
        return res.status(400).json({ success: false, message: 'Invalid file ID' });
    }

    const downloadStream = gfs.openDownloadStream(new ObjectId(fileId));

    downloadStream.on('file', (file) => {
        if (!file.contentType) {
            console.error('Content-Type not set for file:', file._id);
        }
        res.setHeader('Content-Type', file.contentType || 'application/octet-stream');
    });

    downloadStream.on('data', (chunk) => {
        res.write(chunk);
    });

    downloadStream.on('end', () => {
        res.end();
    });

    downloadStream.on('error', (err) => {
        console.error('Error serving file from GridFS:', err);
        return res.status(404).json({ success: false, message: 'File not found' });
    });
});





module.exports = router;
