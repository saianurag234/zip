const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/auth');
const paypalRoutes = require('./routes/paypal'); 
const mongoRoutes = require('./routes/mongodb'); 

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));


// Routes
app.use('/auth', authRoutes);
app.use('/paypal', paypalRoutes);
app.use('/mongodb', mongoRoutes);

// Serve the HTML files
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.get('/patient_dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'views/patient_dashboard.html'));
});

app.get('/doctor_dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'views/doctor_dashboard.html'));
});

app.get('/patient_info', (req, res) => {
    res.sendFile(path.join(__dirname, 'views/patient_information.html'));
});

app.get('/confirmation', (req, res) => {
    res.sendFile(path.join(__dirname, 'views/confirmation.html'));
});

app.get('/conf_app', (req, res) => {
    res.sendFile(path.join(__dirname, 'views/confirmation_appointment.html'));
});

app.get('/admin_dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'views/admin_dashboard.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server started on port ${PORT}`);
});
